# 独立验证

无需启动 Unreal、ComfyUI 或 Web UI。使用 Python 3.11+：

```powershell
python tools/verify_release.py <发布包.zip>
```

验证器重新打开原 ZIP，检查清单与每个文件哈希，并复核二维闭环、PBR、四域 Scene Delta、灯光单域纠正、MCP 边界和图生 3D 接纳证据。退出码 0 表示通过，任何已声明内容被修改都会返回非零。
